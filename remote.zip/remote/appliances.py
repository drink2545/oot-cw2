class light():
    def on(self):
        print('light on')
    def off(self):
        print('light off')

class ac():
    def turn_on(self):
        print('AC on')
    def turn_off(self):
        print('AC off')

class tv():
    def turn_on(self):
        print('Fan on')
    def turn_off(self):
        print('Fan off')
