from weather_data import *
class display():
    def update(self, temp, pressure, humidity):
        self.temp = temp
        self.pressure = pressure
        self.humidity = humidity

        self.render_display()

    def render_display(self):
        print('----')
        print(f'current temperature: {self.temp}')
        print('----')