from weather_data import *
from display import *
import time

def main():
    show = display.update()
main()